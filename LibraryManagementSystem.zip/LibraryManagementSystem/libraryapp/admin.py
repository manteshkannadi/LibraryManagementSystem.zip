from django.contrib import admin
from libraryapp.models import book

admin.site.register(book)
