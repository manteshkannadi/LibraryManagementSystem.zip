
from django.db import models

class book(models.Model):
    ISBN=models.IntegerField()
    Title=models.CharField(max_length=100)
    Author=models.CharField(max_length=200)
    Edition=models.IntegerField()
    Publication=models.CharField(max_length=200)
    Image=models.ImageField(upload_to="images/")


    

    def __str__(self):
        return self.Title
        

