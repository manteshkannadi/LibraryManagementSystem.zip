from django.urls import path
from libraryapp import views

urlpatterns = [
    path("list/",views.book_list_view),
    path("detail/<int:id>/",views.book_detail_view),
    path("delete/<int:id>/",views.book_delete_view),
    path("add/",views.book_add_view),
    path("update/<int:id>/",views.book_update_view),
    path("register/",views.user_registration_view)
]